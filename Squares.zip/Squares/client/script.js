const fade = document.getElementById("fade");
const mainLogin = document.getElementById("login");
const closeLogin = document.getElementById("loginClear");
const mainSignup = document.getElementById("signup");
const closeSignup = document.getElementById("signupClear");

const loginForm = document.forms[0];
const loginUsername = loginForm.elements["username"];
const loginPass = loginForm.elements["pass"];
const loginUsernameInput = document.getElementById("usernameInput");
const loginPasswordInput = document.getElementById("passwordInput");

const signupForm = document.forms[1];
const signUsername = signupForm.elements["username"];
const signPass = signupForm.elements["pass"];
const signConfirmPass = signupForm.elements["confirmPass"];

if(JSON.stringify(document.cookie).split("=")[1] == null) {
} else {
  window.location = '/home.html';
}

mainLogin.onclick = event => {
    document.getElementById("loginForm").style.display = "block";
    document.getElementById("fade").style.display = "block";
    fetch("/getUsernames", {});
}

closeLogin.onclick = event => {
    document.getElementById("loginForm").style.display = "none";
    document.getElementById("fade").style.display = "none";
    loginUsername.value = "";
    loginPass.value = "";
}

mainSignup.onclick = event => {
    document.getElementById("signupForm").style.display = "block";
    document.getElementById("fade").style.display = "block";
    fetch("/getCount", {});
    fetch("/getUsernames", {});
}

closeSignup.onclick = event => {
    document.getElementById("signupForm").style.display = "none";
    document.getElementById("fade").style.display = "none";
    signUsername.value = "";
    signPass.value = "";
    signConfirmPass.value = "";
}

loginUsernameInput.onchange = event => {
    fetch("/postUsername", {
        method: "POST",
        body: JSON.stringify({ user: loginUsername.value }),
        headers: { "Content-Type": "application/json" }
    });
}
  
loginPasswordInput.onchange = event => {
    fetch("/postPassword", {
        method: "POST",
        body: JSON.stringify({ pass: loginPass.value }),
        headers: { "Content-Type": "application/json" }
    });
}

loginForm.onsubmit = event => {
  event.preventDefault();
  fetch("/getHome")
  .then(res => res.json())
  .then(response => {
      if(response.status == 0) {
          alert('Username not registered');
      } else if(response.status == 1) {
          alert('Incorrect Password');
      } else if(response.status == 2) {
          alert('Login Successful');
          window.location = '/home.html';
          document.getElementById("loginForm").style.display = "none";
          document.getElementById("fade").style.display = "none";
      }
  });
}

signupForm.onsubmit = event => {
  event.preventDefault();
  if((signPass.value != signConfirmPass.value)) { 
    alert('Passwords do not match');
    return;
  } else if(signPass.value.length < 5) {
    alert('Password should be atleast 5 characters long')
    return;
  } else {
    const data = { 
      user: signUsername.value, 
      pass: signPass.value 
    }

    fetch("/addUser", {
      method: "POST",
      body: JSON.stringify(data),
      headers: { "Content-Type": "application/json" }
    })
    .then(res => res.json())
    .then(response => {
      if(response.status == 0) {
        alert('Username Already Exists');
      } else {
        alert('Signup Successful');
        document.getElementById("signupForm").style.display = "none";
        document.getElementById("fade").style.display = "none";
        signUsername.value = "";
        signPass.value = "";
        signConfirmPass.value = "";
      }
    });
  }
}