const logoutButton = document.getElementById("logoutButton");
const itemList = document.getElementById("list");
const body = document.getElementById("body");
const profile = document.getElementById("user");

const newColorForm = document.forms[0];
const newColorName = newColorForm.elements["colorName"];
const newColorCode = newColorForm.elements["colorCode"];
const newColorPrice = newColorForm.elements["colorPrice"];
const newColorStock = newColorForm.elements["colorStock"];
const newColorSubmit = document.getElementById("newColorSubmit");
const newColorClose = document.getElementById("newColorClear");

let items = [];
let credits = 0;
let username = JSON.stringify(document.cookie).split("=")[1].replace('"','');
let newColorButton;
let listInteracts = [];

const addItem = (id, name, color, price, stock) => {
  const colorId = id; 

  const block = document.createElement("button");
  block.id = name;
  block.className = "block";

  const nameDiv = document.createElement("div");
  nameDiv.className = "nameDiv";
  const square = document.createElement("div");
  square.className = "colorDiv";
  square.style.backgroundColor = color;
  const itemName = document.createElement("h4");
  itemName.className = "itemName";
  itemName.innerHTML = name;

  const itemPrice = document.createElement("h4");
  itemPrice.className = "itemDetails";
  itemPrice.innerHTML = price;
  const itemStock = document.createElement("h4");
  itemStock.className = "itemDetails";
  itemStock.innerHTML = stock;

  let buyQuantity = 0;

  block.onclick = event => {
    document.getElementById("buyColorFade").style.display = "block";
    document.getElementById("buyColorForm").style.display = "block";
    document.getElementById("buyColorHead").innerHTML = "Buy: "+ name;
    document.getElementById("buyColorColor").style.backgroundColor = color;
    document.getElementById("buyColorPrice").innerHTML = "Price: "+ price;
    document.getElementById("buyColorTotalCost").innerHTML = "Total: ";

    document.getElementById("buyColorQuantityInput").onchange = event => {
      buyQuantity = document.getElementById("buyColorQuantityInput").value;
      document.getElementById("buyColorTotalCost").innerHTML = "Total: "+ (price*parseInt(buyQuantity));
    }

    document.getElementById("buyColorSubmit").onclick = event => {
      quantity = parseInt(buyQuantity);
      if(quantity > 0 && quantity < 1000) {
        const data = {
          user: username,
          colorname: name,
          price: price,
          quantity: quantity,
          total: price*parseInt(buyQuantity)
        }
        fetch("/buyColor", {
          method: "POST",
          body: JSON.stringify(data),
          headers: { "Content-Type": "application/json" }
        })
        .then(res => res.json())
        .then(response => {
          if(response.status == -1) {
            alert('Database Error');
          } else if(response.status == 0) {
            alert('User does not have enough Credits');
          } else if(response.status == 1) {
            alert('Not enough items in Stock');
          } else {
            alert('Transaction Complete');
            document.getElementById("buyColorForm").style.display = "none";
            document.getElementById("buyColorFade").style.display = "none";
            document.getElementById("buyColorQuantityInput").value = 0;
            location.reload(true);
          }
        });
      } else {
        alert('Invalid Input');
      }
    }
  
    document.getElementById("buyColorClear").onclick = event => {
      document.getElementById("buyColorFade").style.display = "none";
      document.getElementById("buyColorForm").style.display = "none";
      document.getElementById("buyColorQuantityInput").value = "";
      buyQuantity = 0;
    }
  }
  
  nameDiv.appendChild(square);
  nameDiv.appendChild(itemName);
  block.appendChild(nameDiv);
  block.appendChild(itemPrice);
  block.appendChild(itemStock);
  itemList.appendChild(block);
}

if(username == null) {
  window.location = '/index.html';
} else {
  document.getElementById("user").innerHTML = username;
  fetch("/getItems", {})
  .then(res => res.json())
  .then(response => {
    response.forEach(row => {
      if(row.stock != 0) {
        addItem(row.id, row.name, row.color, row.price, row.stock);
      }
    });
  });
}

const getCredits = () => {
  fetch("/getCredits", {
    method: "POST",
    body: JSON.stringify({user: username}),
    headers: { "Content-Type": "application/json" }
  })
  .then(res => res.json())
  .then(response => {
    credits = JSON.stringify(response.credits);
    document.getElementById("creditsView").innerHTML = "Credits : " + credits;
  });
}
getCredits();

if(username == "admin") {
   newColorButton = document.createElement("newColor");
   newColorButton.innerHTML = "Add New Color";
   newColorButton.className = "newColorButton";
   body.appendChild(newColorButton);

   newColorButton.onclick = event => {
      document.getElementById("fade").style.display = "block";
      document.getElementById("newColorForm").style.display = "block";
      fetch("/getColorCount");
      fetch("/getColorNames");
  }

  newColorClose.onclick = event => {
    document.getElementById("fade").style.display = "none";
    document.getElementById("newColorForm").style.display = "none";
      newColorName.value = "";
      newColorCode.value = "";
      newColorPrice.value = "";
      newColorStock.value = "";
  }

  newColorForm.onsubmit = event => {
    const data = {
      name: newColorName.value,
      color: newColorCode.value,
      price: newColorPrice.value,
      stock: newColorStock.value
    }

    fetch("/addNewColor", {
      method: "POST",
      body: JSON.stringify(data),
      headers: { "Content-Type": "application/json" }
    })
    .then(res => res.json())
    .then(response => {
      if(response.status == 0) {
        event.preventDefault();
        alert('Name Already Exists');
      } else {
        alert('New Color Added');
        document.getElementById("newColorForm").style.display = "none";
        document.getElementById("fade").style.display = "none";
        signUsername.value = "";
        signPass.value = "";
        signConfirmPass.value = "";
      }
    });
  }
}

profile.onclick = event => {
  window.location = '/profile.html';
}

logoutButton.onclick = event => {
  const alert = confirm('Confirm Logout');
  if(alert == true) {
    fetch("/logout");
    window.location = '/index.html';
  } else {}
}