let username = "";
let colorNames = [];
let colorColors = [];
let colorPrices = [];
let colorQuantities = [];
itemList = document.getElementById("list");

const getCredits = () => {
    document.getElementById("username").innerHTML = username;
    fetch("/getCredits", {
        method: "POST",
        body: JSON.stringify({user: username}),
        headers: { "Content-Type": "application/json" }
    })
    .then(res => res.json())
    .then(response => {
    credits = JSON.stringify(response.credits);
    document.getElementById("credits").innerHTML = "Credits : " + credits;
    });

    document.getElementById("home").onclick = event => {
        window.location = '/home.html';
    }

    document.getElementById("logoutButton").onclick = event => {
        const alert = confirm('Confirm Logout');
        if(alert == true) {
            fetch("/logout");
            window.location = '/index.html';
        } else {}
    }
}

const addItem = (name, color, price, stock) => {
    const block = document.createElement("button");
    block.id = name;
    block.className = "block";

    const nameDiv = document.createElement("div");
    nameDiv.className = "nameDiv";
    const square = document.createElement("div");
    square.className = "colorDiv";
    square.style.backgroundColor = color;
    const itemName = document.createElement("h4");
    itemName.className = "itemName";
    itemName.innerHTML = name;

    const itemPrice = document.createElement("h4");
    itemPrice.className = "itemDetails";
    itemPrice.innerHTML = price;
    const itemStock = document.createElement("h4");
    itemStock.className = "itemDetails";
    itemStock.innerHTML = stock;

    nameDiv.appendChild(square);
    nameDiv.appendChild(itemName);
    block.appendChild(nameDiv);
    block.appendChild(itemPrice);
    block.appendChild(itemStock);
    itemList.appendChild(block);
}

const getItems = () => {
    fetch("/getProfileItems", {})
    .then(res => res.json())
    .then(response => {
      response.forEach(row => {
          colorNames.push(row.name);
          colorPrices.push(row.price);
          colorColors.push(row.color);
      });
    });
}

if(JSON.stringify(document.cookie) == null) {
    window.location = '/index.html';
} else {
    username = JSON.stringify(document.cookie).split("=")[1].replace('"','');
    getCredits();
    getItems();
    fetch("/getInventory", {
        method: "POST",
        body: JSON.stringify({ user: username }),
        headers: { "Content-Type": "application/json" }
    })
    .then(res => res.json())
    .then(response => {
        colorQuantities = response;
        console.log(colorNames, colorColors, colorPrices, colorQuantities);
        for(let i=0; i< colorNames.length; i++) {
            console.log(colorQuantities[i])
            if(colorQuantities[i] !=0) {
                addItem(colorNames[i], colorColors[i], colorPrices[i], colorQuantities[i]);
            }
        }
    });
}