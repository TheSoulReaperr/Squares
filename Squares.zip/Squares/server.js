const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const mysql = require('mysql');
const { request } = require('http');
const { response } = require('express');

const app = express();
app.listen(3000, () => console.log('Listening . . .'));
app.use(express.static('client'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cookieParser());

let count = 0;
let usernames = [];
let loginUsername = "";
let loginPassword = "";

let colorCount;
let colorNames = [];

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    serverchoice: 'MySQL',
    database: 'squares'
});

connection.connect((error) => {
    if(!!error) {
        console.log(error);
    } else {
        console.log('Connected');
    }
});

app.get("/getUsernames", (request, response) => {
    usernames = [];
    connection.query(`select username from users`, (error, rows, fields) => {
        if(error) {
        } else {
            rows.forEach((item, index) => {
                usernames.push(item.username);
            });
        }
    });
});

app.get("/getCount", (request, response) => {
    connection.query(`select count(*) as count from users`, (error, rows, fields) => {
        if(error) {
        } else {
            rows.forEach((item, index) => {
                count = item.count;
            });
        }
    });
});

app.post("/postUsername", (request, response) => {
    loginUsername = cleanseString(request.body.user);
});

app.post("/postPassword", (request, response) => {
    loginPassword = cleanseString(request.body.pass);
});

app.get("/getHome", (request, response) => {
    const username = loginUsername;
    const password = loginPassword;
    let dbPassword = "";
    if(usernames.includes(username)) {
        connection.query(`select pass from users where username = '${username}'`, (error, rows, fields) => {
            rows.forEach((item, index) => {
                dbPassword = item.pass;
            });
            if(password != dbPassword) {
                response.send({ status: 1 });
            } else {
                response.cookie('username', username).send({ status: 2 });;
            }
        });
    } else {
        response.send({ status: 0 });
    }
});

app.post("/addUser", (request, response) => {
    const username = cleanseString(request.body.user);
    const password = cleanseString(request.body.pass);
    if(usernames.includes(username)) {
        response.send({ status: 0 });
    } else {
        connection.query(`insert into users(id,username,pass,credits,status) values(${count},'${username}','${password}',200,0)`, (error, rows, fields) => {
            if(error) {
                console.log(error);
                response.send({ status: -1 });
                return;
            } else {
                response.send({ status: 1 });
                count++;
            }
        });
    }
});

const cleanseString = (string) => {
    return string.replace(/</g, "&lt;").replace(/>/g, "&gt;");
};

app.get("/logout", (request, response) => {
    response.clearCookie('username');
    response.end();
});

app.post("/getCredits", (request, response) => {
    let data = 0;
    const username = cleanseString(request.body.user);
    connection.query(`select credits from users where username = '${username}'`, (error, rows, fields) => {
        if(error) {
        } else {
            rows.forEach((item, index) => {
                data = item.credits;
            });
            response.send({credits : data});
        }
    });
});

app.get("/getItems", (request, response) => {
    let data =[];
    connection.query(`select id, name, color, price, stock from inventory`, (error, rows, fields) => {
        if(error) {
        } else {
            rows.forEach((item, index) => {
                data.push(item);
            });
            response.send(data);
        }
    });
});

app.get("/getColorCount", (request, response) => {
    connection.query(`select count(*) as count from inventory`, (error, rows, fields) => {
        if(error) {
        } else {
            rows.forEach((item, index) => {
                colorCount = item.count;
            });
        }
    });
});

app.get("/getColorNames", (request, response) => {
    colorNames = [];
    connection.query(`select name from inventory`, (error, rows, fields) => {
        if(error) {
        } else {
            rows.forEach((item, index) => {
                colorNames.push(item.name);
            });
        }
    });
});

app.post("/addNewColor", (request, response) => {
    const name = cleanseString(request.body.name);
    const color = cleanseString(request.body.color);
    const price = cleanseString(request.body.price);
    const stock = cleanseString(request.body.stock);
    if(colorNames.includes(name)) {
        response.send({ status: 0 });
    } else {
        const newId = "c"+(colorCount);
        const result = connection.query(`insert into inventory(id,name,color,price,stock) values(${colorCount},'${name}','${color}','${price}','${stock}')`, (error, rows, fields) => {
            if(error) {
                console.log(error);
                response.send({ status: 0 });
                return;
            } else {
                connection.query(`alter table stock add ${newId} int default 0;`, (error, rows, fields) => {
                });
                response.send({ status: 1 });
                count++;
            }
        });
    }
});

app.post("/buyColor", (request, response) => {
    const username = cleanseString(request.body.user);
    const color = cleanseString(request.body.colorname);
    const quantity = request.body.quantity;
    const total = request.body.total;
    let credits = 0;
    let stock = 0;
    let colorID = "";
    let userID = 0;
    // console.log(username, color, quantity, total);
    connection.query(`select credits,id from users where username = '${username}'`, (error, rows, fields) => {
        rows.forEach((item, index) => {
            credits = item.credits;
            userID = item.id;
        });
        if(credits < total) {
            response.send({ status: 0 });
            return;
        } else {
            connection.query(`select stock,id from inventory where name = '${color}'`, (error, rows, fields) => {
                rows.forEach((item, index) => {
                    stock = item.stock;
                    colorID = "c"+item.id;
                });
                if(stock < quantity) {
                    response.send({ status: 1 });
                } else {
                    connection.query(`update inventory set stock = stock-${quantity} where name = '${color}'`, (error, rows, fields) => {
                        if(error) {
                            response.send({ status: -1 });
                        } else {
                            connection.query(`update stock set ${colorID} = ${colorID} + ${quantity} where userid = ${userID}`, (error, rows, fields) => {
                                if(error) {
                                    response.send({ status: -1 });
                                } else {
                                    connection.query(`update users set credits = credits - ${total} where id = ${userID}`, (error, rows, fields) => {
                                        if(error) {
                                            response.send({ status: -1 });
                                        } else {
                                            response.send({ status: 2 });
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
            });
        }
    });
});

app.get("/getProfileItems", (request, response) => {
    let data = [];
    connection.query(`select name, color, price from inventory`, (error, rows, fields) => {
        if(error) {
            console.log(error);
        } else {
            rows.forEach((item, index) => {
                data.push(item);
            });
            response.send(data);
        }
    });
}); 

app.post("/getInventory", (request, response) => {
    let data =[];
    const username = cleanseString(request.body.user);
    let uID = 0;
    connection.query(`select id from users where username = '${username}'`, (error, rows, fields) => {
        rows.forEach((item, index) => {
            uID = item.id;
        });
        connection.query(`select * from stock where userid = '${uID}'`, (error, rows, fields) => {
            if(error) {
                console.log(error);
            } else {
                rows.forEach((item, index) => {
                    const values = Object.values(item);
                    values.forEach((item, index) => {
                        if(index !=0)
                            data.push(item);
                    });
                });
                response.send(data);
            }
        });
    });
});